import React from "react";

import AdminGraph from "../components/AdminGraph";
import DashboardCard from "../components/DashboardCard";
import SalesByStore from "../components/SalesByStore";
import '../css/ThunderAdmin.css';

const ThunderAdmin=()=>{


  return(
    <>
    <div className="thunderAdmin_all">

      <h1>관리자 번개모임</h1>
   
      
      <AdminGraph/>
      <DashboardCard/>
      <SalesByStore/>






    </div>
    </>
  )
}

export default ThunderAdmin;